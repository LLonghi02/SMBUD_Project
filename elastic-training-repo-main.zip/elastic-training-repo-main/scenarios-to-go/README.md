# Scenarios-to-go
A collection of docker compose files to spin up micro-service architectures fulfilling an Elastic scenario, useful to practice with Elastic solutions to search problems. The name of the folders indicates the kind of scenario.

For more details on how to use these files, please refer to the [Elastic documentation](https://www.elastic.co/guide/en/elasticsearch/reference/master/docker.html).
