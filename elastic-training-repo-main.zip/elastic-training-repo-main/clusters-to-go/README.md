# Clusters-to-go
A collection of docker-compose files to spin up simple Elastic clusters, useful to practice with Elasticsearch. The name of the folders indicates the version of the Elasticsearch instances.

For more details on how to use these files, please refer to the [Elastic documentation](https://www.elastic.co/guide/en/elasticsearch/reference/master/docker.html).
