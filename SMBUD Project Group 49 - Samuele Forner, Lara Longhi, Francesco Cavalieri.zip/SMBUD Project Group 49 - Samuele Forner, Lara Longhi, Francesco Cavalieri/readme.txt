The structure of the delivery folder includes:  
- Pictures: with the following subfolders:
	- Extra: containing the video of how the application work and some screenshot of the App 
	- MongoDB: containing some dump screens of the result of the queries
	- Neo4j: containing some dump screens of the result of the queries
- Databases: with the following subfolders:  
   - MongoDB: containing the CSV file used.  
   - Neo4j: containing the set of uploaded Neo4j files.  
- app-release.apk: the executable application file, which can be installed on Android OS or tested via the website https://appetize.io/. You can also see how it works on https://youtube.com/shorts/HF4cPgwzhKs?feature=share
- Documentation: provided in PDF format.